a,db,mb,yb,td,tm,tyear
from datetime import date
td=hoy().día
tm=hoy().mes
tyear=().year
print="Ingrese su fecha de nacimiento dd/mm/aaaa"
print="Día"
input(td)
print="Mes"
input(tm)
print="Año"
input(tyear)
print="La fecha de hoy es:"+td+"/"+tm+"/"+tyear
a=tyear - yb
if tyear < yb
 print="Todavía no nace"
else tyear==yb
elif mb>tm
 print"Todavía no nace"
if td<db
print"Todavía no nace"
elif
print "Usted tiene cero años"
elif
if mb==tm and db>td or mb>tm
 a=a-1
    print"Tiene" +a+"años"
 